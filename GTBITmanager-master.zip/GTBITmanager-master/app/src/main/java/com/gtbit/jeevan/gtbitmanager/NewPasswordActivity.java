package com.gtbit.jeevan.gtbitmanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NewPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);
    }
}
