package com.gtbit.jeevan.gtbitmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    private TextInputLayout usernameTIL, passwordTIL;
    private TextInputEditText username, password;
    private Button signIn;
    private TextView forgotPasswordTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.username_editText);
        password = findViewById(R.id.password_editText);
        usernameTIL = findViewById(R.id.username_textInput);
        passwordTIL = findViewById(R.id.password_textInput_layout);
        signIn = findViewById(R.id.login_button);
        forgotPasswordTextView = findViewById(R.id.forgot_password_tv);


        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean check = validatePassword() && validateUsername();
                if (check) {
                    //TODO: check for enrollment number and password from DB
                } else {
                    if (!validateUsername()) {
                        username.setError("Enter enrollment number");
                        requestFocus(username);
                    } else {
                        password.setError("Enter password");
                        requestFocus(password);
                    }
                }
            }
        });
        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,NewPasswordActivity.class));
            }
        });

    }

    private boolean validateUsername() {
        if (username.getText().toString().trim().length() == 0) {
            return false;
        }
        return true;
    }

    private boolean validatePassword() {

        if (password.getText().toString().trim().length() == 0) return false;
        return true;
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }


}
